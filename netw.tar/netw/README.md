# netw //from 0 to infinity
